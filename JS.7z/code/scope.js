/**
 * Created by sagakulk on 6/8/2016.
 */

function foo(){
    x=10;
    console.log(x);

    function bar(){
        x=15;
        console.log(x);
    }
    bar();
}

