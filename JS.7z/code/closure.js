/**
 * Created by sagakulk on 6/8/2016.
 */
var bar=(function foo() {
        console.log("foo");

    return function(){
        console.log("bar");
    }
})();

