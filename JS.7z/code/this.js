/**
 * Created by sagakulk on 6/9/2016.
 */

var foo =function(){
    this.x = 20;
    this.y = 30;
}
foo();
console.log(x,y)

var f = new foo();
console.log(f.x, f.y)

var obj1 = {
        f:foo
}

obj1.f();
console.log(obj1.x,obj1.y);

var obj2 = {
        f:obj1.f
}

obj2.f();

console.log(obj2.x,obj2.y);

var obj3 = new obj2.f();
console.log(obj3.x,obj3.y);

var obj4 = {};
foo.apply(obj4);
console.log(obj4.x,obj4.y);

var obj5 = {}
obj2.f.apply(obj5);
console.log(obj5.x,obj5.y);

/*
var obj6 = {}

new foo.apply(obj6);

console.log(obj6.x,obj6.y);
*/





































