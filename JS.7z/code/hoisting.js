/**
 * Created by sagakulk on 6/8/2016.
 */


foo();

console.log(x);