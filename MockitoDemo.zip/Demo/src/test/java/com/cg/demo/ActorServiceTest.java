package com.cg.demo;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cg.demo.pojo.Actor;
import com.cg.demo.repo.ActorRepo;
import com.cg.demo.service.ActorService;
import com.cg.demo.service.ActroServiceImpl;


public class ActorServiceTest{

	private ActorService service;
	
	@Mock private ActorRepo repo;
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		service = new ActroServiceImpl(repo); 
	}
	
	//1. When passed Sunil Shetty, createActor should create the Actor Record.
	@Test
	public void sunilShettyIsAnActor(){
		
		Mockito.when(repo.save(new Actor("Sunil Shetty"))).thenReturn(true);
		
		assertEquals("Sunil Shetty", service.createActor("Sunil Shetty").getName());
	}
	
	//2. Sunil Shetty exists in system.
	
	@Test
	public void sunilShettyExistsInSystem(){

		Actor a = new Actor("Sunil Shetty");
		Mockito.when(repo.findByName("Sunil Shetty")).thenReturn(a);
		
		assertEquals(a, service.findByName("Sunil Shetty"));
	}
	
	//3. Amitabh Bachhan
	
	@Test
	public void amitabhBachhanDoesNotExistInSystem(){

		
		Mockito.when(repo.findByName("Amitabh Bachhan")).thenReturn(null);
		
		assertEquals(null, service.findByName("Amitabh Bachhan"));
	}
	
	
	
}



