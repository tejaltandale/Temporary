package com.cg.demo.service;

import com.cg.demo.pojo.Actor;
import com.cg.demo.repo.ActorRepo;

public class ActroServiceImpl implements ActorService {

	private ActorRepo repo;
	public ActroServiceImpl(ActorRepo repo) {
		super();
		this.repo = repo;
	}

	public Actor createActor(String name) {
		Actor a = new Actor(name);
		if(repo.save(a))
			return a;
		return null;
	}

	public Actor findByName(String name) {
		Actor a = repo.findByName(name);
		return a;
	}

}
