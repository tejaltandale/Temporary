package com.cg.demo.service;

import com.cg.demo.pojo.Actor;

public interface ActorService {

	public Actor createActor(String name);
	
	public Actor findByName(String name);
}
