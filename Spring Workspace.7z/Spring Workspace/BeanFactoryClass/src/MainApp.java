
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

@SuppressWarnings("deprecation")
public class MainApp {

	public static void main(String[] args) {

		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("Beans.xml"));
		System.out.println("Name constructor");
		Employee obj = (Employee) factory.getBean("emp1");

		System.out.println(obj.getId());
		System.out.println(obj.getName());

		System.out.println("Id constructor");
		Employee obj1 = (Employee) factory.getBean("emp2");

		System.out.println(obj1.getId());
		System.out.println(obj1.getName());

		Employee obj2 = (Employee) factory.getBean("emp3");

		System.out.println("name and Id constructor");
		System.out.println(obj2.getId());
		System.out.println(obj2.getName());

	}

}
