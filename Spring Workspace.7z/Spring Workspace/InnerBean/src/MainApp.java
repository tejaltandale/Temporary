import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
		Employee obj = (Employee)context.getBean("emp");
		
		System.out.println(obj.getId());
		System.out.println(obj.getName());
		System.out.println(obj.getAddress().getCity());
 	}

}
