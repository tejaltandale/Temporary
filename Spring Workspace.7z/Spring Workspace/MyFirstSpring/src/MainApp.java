
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

		System.out.println("Name constructor");
		Employee obj = (Employee) context.getBean("emp1");

		System.out.println(obj.getId());
		System.out.println(obj.getName());

		System.out.println("Id constructor");
		Employee obj1 = (Employee) context.getBean("emp2");

		System.out.println(obj1.getId());
		System.out.println(obj1.getName());

		Employee obj2 = (Employee) context.getBean("emp3");

		System.out.println("name and Id constructor");
		System.out.println(obj2.getId());
		System.out.println(obj2.getName());

	}

}
