package com.flp.ems.domain;

import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Entity
public class Actor {
	@Id @GeneratedValue(strategy=GenerationType.AUTO) 
	int id;
	String firstName;
	String lastName;
	String gender;
	
	@OneToOne
	Album album;
	Date createDate;
	Date deleteDate;
	
	@ManyToMany
	List <Film> film;
	
	//Constructors
	
	public Actor() {
		super();
	}
	
	public Actor(int id) {
		super();
		this.id = id;
	}



	//getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Album getAlbum() {
		return album;
	}

	public void setAlbum(Album album) {
		this.album = album;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public List<Film> getFilm() {
		return film;
	}

	public void setFilm(List<Film> film) {
		this.film = film;
	}
	
	//ToString
	@Override
	public String toString() {
		return "Actor [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender
				+ ", album=" + album + ", createDate=" + createDate + ", deleteDate=" + deleteDate + ", film=" + film
				+ "]";
	}
	

	
	

}
