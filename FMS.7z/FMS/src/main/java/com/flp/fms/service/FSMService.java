package com.flp.fms.service;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Album;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;

public class FSMService {
	
	protected EntityManager em;
	public FSMService(EntityManager em){
		this.em=em;
	}
	
	public Film createFilm(Date createDate, String description, String language, short length, byte rating, Date releaseYear,
			String title, List<Actor> actor, List<Category> category, Album album) {
		Film f = new Film();
		f.setTitle(title);
		f.setDescription(description);
		f.setReleaseYear(releaseYear);
		f.setLanguage(language);
		f.setActor(actor);
		f.setCategory(category);
		f.setRating(rating);
		f.setCreateDate(createDate);
		f.setLength(length);
		f.setAlbum(album);
		em.persist(f);
		return f;
		
	}
	

}
