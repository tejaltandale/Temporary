package com.flp.fms.view;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Album;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.fms.service.FSMService;





public class BootClass {

	public static void main(String[] args) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("fms");
		EntityManager em = emfactory.createEntityManager();
		FSMService film = new FSMService(em);
		em.getTransaction().begin();
		Film f = film.createFilm(new Date(),"action","english",(short)4,(byte)4,new Date(),"John wick",null,null,null);
//		film.setActor(null);
//		film.setCategory(null);
//		film.setAlbum(null);
//		film.setTitle("John WIck");
//		film.setDescription("Action");
//		film.setReleaseYear(new Date(2016));
//		film.setLanguage("english");
//		film.setRating((byte)4);
//		film.setLength((short)180);
//		film.setCreateDate(new Date(System.currentTimeMillis()));
		
		
		em.getTransaction().commit();
		em.close();
		emfactory.close();
		
	}

}

