package com.fms.pojo;



import java.util.Date;
import java.util.List;



public class Film {
	
	
	
	int id;
	Date createDate;
	Date deleteDate;
	String description;
	String language;
	short length;
	byte rating;
	Date releaseYear;
	
	String title;
	
	
	
	

	List <Actor> actor;
	

	List <Category> category;
	
	
	
		Album album;
	
	
	
	
	
	//Constructors
	
	public Film() {
		super();
	}
	
	public Film(int id) {
		super();
		this.id = id;
	}

	//Setters and getters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public List<Actor> getActor() {
		return actor;
	}
	public void setActor(List<Actor> actor) {
		this.actor = actor;
	}
	public List<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	public byte getRating() {
		return rating;
	}
	public void setRating(byte rating) {
		this.rating = rating;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public short getLength() {
		return length;
	}
	public void setLength(short length) {
		this.length = length;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	
	//ToString
	@Override
	public String toString() {
		return "Film [id=" + id + ", title=" + title + ", description=" + description + ", releaseYear=" + releaseYear
				+ ", language=" + language + ", actor=" + actor + ", category=" + category + ", rating=" + rating
				+ ", deleteDate=" + deleteDate + ", createDate=" + createDate + ", length=" + length + ", album="
				+ album + "]";
	}



	
	
	
	

}

