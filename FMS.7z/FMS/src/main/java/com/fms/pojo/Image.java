package com.fms.pojo;

import java.util.Date;

public class Image {
	int id;
	String imageUrl;
	Date createDate;
	Date deleteDate;
	
	//constructors
	public Image() {
		super();
	}

	public Image(int id) {
		super();
		this.id = id;
	}
	
	//getters and setters

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	
	//tostring
	@Override
	public String toString() {
		return "Image [id=" + id + ", imageUrl=" + imageUrl + ", createDate=" + createDate + ", deleteDate="
				+ deleteDate + "]";
	}
	
	
}
