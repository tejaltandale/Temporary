package com.fms.service;


import java.util.List;

import org.mockito.Mockito;

import com.fms.dao.IFilmDao;
import com.fms.pojo.Film;

public class FilmServiceImpl implements IFilmService {

	private IFilmDao dao;
	
	public FilmServiceImpl(IFilmDao dao) {
		super();
		this.dao = dao;
	}


	public String addFilm(Film f) {
		if (f == null) {
			throw new NullPointerException();
		}
		
		
		if (f.getTitle()==null) throw new IllegalArgumentException();
		if (f.getDescription()==null) throw new IllegalArgumentException();
		if (f.getReleaseYear()==null) throw new IllegalArgumentException();
		if (f.getLanguage()==null) throw new IllegalArgumentException();
		if (f.getActor()==null) throw new IllegalArgumentException();
		if (f.getCategory()==null) throw new IllegalArgumentException();
		if (f.getRating()==0 || f.getRating()>5) throw new IllegalArgumentException();
		if (f.getCreateDate()==null) throw new IllegalArgumentException();
		if (f.getLength()==0) throw new IllegalArgumentException();
		if (f.getAlbum()==null) throw new IllegalArgumentException();
		
		
		if (dao.addFilm(f)) {
			return "success";
		}
	
		return "fail";
	}



	public List<Film> searchByTitle(String title) {
		Mockito.when(dao.)
		
		return null;
	}



	public String modifyFilm(String title) {
		if (title == null ) {
			return "fail";
		}
		
		return null;
	}



	public String deleteFilm(String title) {
		
		return null;
	}

}
