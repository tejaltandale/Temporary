package com.fms.dao;

import java.util.List;

import com.fms.pojo.Film;

public interface IFilmDao {
	public boolean addFilm (Film film);
	
	public List<Film> searchByTitle(String title);
	
	public String modifyFilm(String title);
	
	public String deleteFilm(String title);	
}
