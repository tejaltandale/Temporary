package com.fms.dao;

import com.fms.pojo.Film;

public class IFilmDaoImpl implements IFilmDao {

	public boolean addFilm(Film film) {
		return true;
	}

}
