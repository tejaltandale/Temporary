package com.flp.fms.view;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Album;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Image;
import com.flp.fms.service.FSMService;





public class BootClass {

	public static void main(String[] args) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("fms");
		EntityManager em = emfactory.createEntityManager();
		FSMService film = new FSMService(em);
		em.getTransaction().begin();
		
		Image image1 = film.createImage("URL",null,null);
		Image image2 = film.createImage("URL2",null,null);
		Image image3 = film.createImage("URL3",null,null);
		
		List<Image> images = new ArrayList <Image>();
		images.add(image1);
		images.add(image2);
		images.add(image3);
		
			
		
		
		Album album = film.createAlbum("Photos",images,null,null);
		
		Category c1 = film.createCategory("Action", null, null);
		Category c2 = film.createCategory("Sci-Fi", null, null);
		Category c3 = film.createCategory("Adventure", null, null);
		
		
		List<Category> categories = new ArrayList<Category>();
		categories.add(c1);
		categories.add(c2);
		categories.add(c3);
		
		Actor a1 = film.createActor("Keanu", "Reaves", "Male", album, null, null);
	
		
		List <Actor> actors = new ArrayList<Actor>();
		actors.add(a1);
	
		
		
		film.createFilm(null, "Nice movie", "English", (short)190, (byte)4, null, "John Wick", actors, categories, album);
				
		em.getTransaction().commit();
		em.close();
		emfactory.close();
		
	}

}

