package com.flp.fms.service;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Album;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Image;

public class FSMService {
	
	protected EntityManager em;
	public FSMService(EntityManager em){
		this.em=em;
	}
	
	public Film createFilm(Date createDate, String description, String language, short length, byte rating, Date releaseYear,
			String title, List<Actor> actor, List<Category> category, Album album) {
		Film f = new Film();
		f.setTitle(title);
		f.setDescription(description);
		f.setReleaseYear(releaseYear);
		f.setLanguage(language);
		f.setActor(actor);
		f.setCategory(category);
		f.setRating(rating);
		f.setCreateDate(createDate);
		f.setLength(length);
		f.setAlbum(album);
		em.persist(f);
		return f;
		
	}
	
	public Album createAlbum(String albumName,List<Image> image,Date createDate,Date deleteDate) {
		Album album = new Album();
		album.setCreateDate(createDate);
		album.setDeleteDate(deleteDate);
		album.setImage(image);
		album.setAlbumName(albumName);
		em.persist(album);
		return null;
		
	}
	
	public Image createImage(String imageUrl,Date createDate,Date deleteDate) {
		Image image = new Image();
		image.setCreateDate(createDate);
		image.setDeleteDate(deleteDate);
		image.setImageUrl(imageUrl);
		em.persist(image);
		return image;
	}
	
	public Category createCategory (String name,Date createDate,Date deleteDate) {
		Category category = new Category();
		category.setCreateDate(createDate);
		category.setDeleteDate(deleteDate);
		category.setName(name);
		em.persist(category);
		return category;
	}
	
	public Actor createActor(String firstName,String lastName,String gender,Album album,Date createDate,Date deleteDate) {
		Actor actor = new Actor();
		actor.setFirstName(firstName);
		actor.setLastName(lastName);
		actor.setCreateDate(createDate);
		actor.setDeleteDate(deleteDate);
		actor.setAlbum(album);
		actor.setGender(gender);
		
		em.persist(actor);
		
		
		return actor;
	}

}
