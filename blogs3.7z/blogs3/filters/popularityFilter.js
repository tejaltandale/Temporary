/**
 * Created by jehaque on 15-Jun-16.
 */

helloApp.filter("popularity", function (){
   /* var max = 0;
   return function (value) {
       console.log("pop")


       if(value>max) {
           max = value;
           console.log(max)
       }
       /!*if (value < 150) {
           return "Not popular"
       }
       else {
           return "Popular"
       }
       *!/
       return  (5 * value )/ max;*/
    var max = 0;
    return function(input, total) {
        total = parseInt(total);
        
        if (total > max) {
            max = total;
        }
        total=Math.round((5*total)/max);

        for (var i=0; i<total; i++) {
            input.push(i);
        }
        
        return input;
    };
   
});
