/**
 * Created by jehaque on 13-Jun-16.
 */

var blogController = helloApp.controller('blogController', function ($scope) {
    $scope.searchText = " ";
    $scope.blogs = [

        {
            title: "Man's Search for Meaning",
            author: "Viktor Frankl",
            year: "1946",
            image: "images/man.jpg",
            likeCount: "15",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at neque ut orci pulvinar maximus. Proin convallis tempus efficitur. Pellentesque vulputate neque vitae ex tempus mattis. Integer cursus mi non nisl porttitor, vel tristique sem tincidunt. Donec ullamcorper augue ut vulputate euismod."
        },
        {
            title: "Sherlock Holmes",
            author: "Sir Arthur Conan Doyle",
            year: "1887",
            image: "images/she.jpg",
            likeCount: "25",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at neque ut orci pulvinar maximus. Proin convallis tempus efficitur. Pellentesque vulputate neque vitae ex tempus mattis. Integer cursus mi non nisl porttitor, vel tristique sem tincidunt. Donec ullamcorper augue ut vulputate euismod."
        },

        {
            title: "The Immortals of Meluha",
            author: "Amish Tripathi",
            image: "images/mel.jpg",
            year: "2010",
            likeCount: "52",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at neque ut orci pulvinar maximus. Proin convallis tempus efficitur. Pellentesque vulputate neque vitae ex tempus mattis. Integer cursus mi non nisl porttitor, vel tristique sem tincidunt. Donec ullamcorper augue ut vulputate euismod."
        }, {
            title: "Creativity",
            author: "Osho",
            image: "images/osho.jpg",
            year: "2010",
            likeCount: "36",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at neque ut orci pulvinar maximus. Proin convallis tempus efficitur. Pellentesque vulputate neque vitae ex tempus mattis. Integer cursus mi non nisl porttitor, vel tristique sem tincidunt. Donec ullamcorper augue ut vulputate euismod."
        }, {
            title: "Scion of Ikshvaku",
            author: "Amish Tripathi",
            image: "images/sci.jpg",
            year: "2015",
            likeCount: "10",
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at neque ut orci pulvinar maximus. Proin convallis tempus efficitur. Pellentesque vulputate neque vitae ex tempus mattis. Integer cursus mi non nisl porttitor, vel tristique sem tincidunt. Donec ullamcorper augue ut vulputate euismod."
        }
    ]
    
        
    $scope.upVoteCount= function(blog) {
      blog.likeCount++;
        
    }
});