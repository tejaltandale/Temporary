/**
 * Created by jehaque on 09-Jun-16.
 */
function sendRequest(){
    var XHR = getXHR();
    if(XHR){
        XHR.open("GET","data.json",true);
        XHR.onreadystatechange = function(){handleResponse(XHR);}
        XHR.send();
    }
}

function getXHR(){
    return new XMLHttpRequest();
}

function handleResponse(XHR){
    if(XHR.readyState==4){
    

        var sideBar= document.getElementById('addData');
        var persons = JSON.parse(XHR.responseText);

        for(var i=0;i<persons.length;i++) {
            var btn = document.createElement("BUTTON");
            var t = document.createTextNode(persons[i].firstName + ', '+persons[i].lastName);
            btn.appendChild(t);
            sideBar.appendChild(btn);
        }

    }
}