package com.fms.dao;

import java.util.List;

import com.fms.pojo.Actor;
import com.fms.pojo.Film;

public interface IFilmDao {
	boolean save(Film film);
	boolean modifyFilm(Film film);
	boolean deleteFilm(Film film);
	List<Film> searchFilmByTitle(String title);
	List<Film> searchFilmByCategory(String category);
	List<Film> searchFilmByRating(short rating);
	List<Film> searchFilmByLanguage(String lang);
	List<Film> searchFilmByActor(Actor actor);
	List<Film> searchFilmByRealeaseYear(short year);
	

}
