package com.fms.service.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fms.dao.IFilmDao;
import com.fms.pojo.Actor;
import com.fms.pojo.Album;
import com.fms.pojo.Category;
import com.fms.pojo.Film;
import com.fms.service.FilmServiceImpl;

public class FilmServiceTestCases {

	private FilmServiceImpl service;

	@Mock
	private IFilmDao dao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		service = new FilmServiceImpl(dao);
	}

	/* ----------------- addFilm method test cases ------------------------ */

	// if details are valid values should be added
	@Test
	public void ifDetailsAreValidFilmShouldBeAdded() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("Academy award winner");
		film.setLanguage("English");
		film.setLength((short) 156);
		film.setRating((byte) 5);
		film.setReleaseYear((short) 2015);
		film.setTitle("The Revenant");

		Mockito.when(dao.save(film)).thenReturn(true);

		assertEquals("success", service.addFilm(film));
	}

	// If details are valid but not added for system error
	@Test(expected = java.lang.Exception.class)
	public void ifSystemError() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("Academy award winner");
		film.setLanguage("English");
		film.setLength((short) 156);
		film.setRating((byte) 5);
		film.setReleaseYear((short) 2015);
		film.setTitle("The Revenant");

		Mockito.when(dao.save(film)).thenThrow(new SQLException());

		service.addFilm(film);
	}

	// if details are not valid should not be added
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void ifDetailsAreNotValidFilmShouldNotBeAdded() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("Academy award winner");
		film.setLanguage("English");
		film.setLength((short) 156);
		film.setRating((byte) 8);
		film.setReleaseYear((short) 2015);
		film.setTitle("The Revenant");

		Mockito.when(dao.save(film)).thenReturn(false);

		service.addFilm(film);
	}

	// if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void ifFilmIsNull() {
		Film film = null;

		Mockito.when(dao.save(film)).thenReturn(false);

		service.addFilm(film);
	}

	/*----------------- modifyFilm() test cases -------------*/

	// if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNull() {
		Film film = null;

		Mockito.when(dao.modifyFilm(film)).thenReturn(false);

		service.modifyFilm(film);
	}

	// if system error occurs
	@Test(expected = java.lang.Exception.class)
	public void ifSystemErrorInModifyFilm() {
		Film film = new Film(2);
		Mockito.when(dao.modifyFilm(film)).thenThrow(new SQLException());
		service.modifyFilm(film);
	}

	// if search data is not present
	@Test
	public void dataIsNotPresent() {
		Film film = new Film(2);
		Mockito.when(dao.modifyFilm(film)).thenReturn(false);
		assertEquals("fail", service.modifyFilm(film));
	}

	// if data is present it should modify data
	@Test
	public void ifDataIsPresent() {
		Film film = new Film(1);
		Mockito.when(dao.modifyFilm(film)).thenReturn(true);
		assertEquals("success", service.modifyFilm(film));

	}
	/*----------------- deleteFilm() test cases -------------*/

	// if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNullDelete() {
		Film film = null;
		Mockito.when(dao.deleteFilm(film)).thenReturn(false);
		service.deleteFilm(film);
	}

	// if data is not present
	@Test
	public void dataIsNotPresentDelete() {
		Film f = new Film(2);
		Mockito.when(dao.deleteFilm(f)).thenReturn(false);
		assertEquals("fail", service.deleteFilm(f));
	}

	// if data is present delete the film
	@Test
	public void ifDataIsPresentDelete() {
		Film film = new Film(1);
		Mockito.when(dao.deleteFilm(film)).thenReturn(true);
		assertEquals("success", service.deleteFilm(film));

	}

	// if data is present but cannot be delete for system error
	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInDeleteFilm() {
		Film film = new Film(2);
		Mockito.when(dao.deleteFilm(film)).thenThrow(new SQLException());
		service.deleteFilm(film);
	}

	/*----------------- searchByTitle() test cases -------------*/

	@Test(expected = java.lang.NullPointerException.class)
	public void findByTitleInputNull() {
		service.searchFilmByTitle(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByTilteInputNotPresent() {

		Mockito.when(dao.searchFilmByTitle("abc")).thenReturn(null);
		service.searchFilmByTitle("abc");

	}

	@Test
	public void findByTitleIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(dao.searchFilmByTitle("Sultan")).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));
		assertFalse(service.searchFilmByTitle("Sultan").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByTitleIfSystemError() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(dao.searchFilmByTitle("Sultan")).thenThrow(new SQLException());
		service.searchFilmByTitle("Sultan");

	}

	/*----------------- searchByCategory() test cases -------------*/

	@Test(expected = java.lang.NullPointerException.class)
	public void findByCategoryInputNull() {
		service.searchFilmByCategory(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByCategoryInputNotPresent() {

		Mockito.when(dao.searchFilmByCategory("abc")).thenReturn(null);
		service.searchFilmByCategory("abc");

	}

	@Test
	public void findByCategoryIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(dao.searchFilmByCategory("Sultan")).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));
		assertFalse(service.searchFilmByCategory("Sultan").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByCategoryIfSystemError() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(dao.searchFilmByCategory("Sultan")).thenThrow(new SQLException());
		service.searchFilmByCategory("Sultan");

	}

	/*----------------- searchByRating() test cases -------------*/

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void findByRatingInputNull() {
		service.searchFilmByRating((short) 0);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByRatingInputNotPresent() {

		Mockito.when(dao.searchFilmByRating((short) 3)).thenReturn(null);
		service.searchFilmByRating((short) 3);

	}

	@Test
	public void findByRatingIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(dao.searchFilmByRating((short) 3)).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));
		assertFalse(service.searchFilmByRating((short) 3).isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByRatingIfSystemError() {

		Mockito.when(dao.searchFilmByRating((short) 3)).thenThrow(new SQLException());
		service.searchFilmByRating((short) 3);

	}

	/*----------------- searchByLanguage() test cases -------------*/

	@Test(expected = java.lang.NullPointerException.class)
	public void findByLanguageInputNull() {
		service.searchFilmByLanguage(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByLanguageInputNotPresent() {

		Mockito.when(dao.searchFilmByLanguage("abc")).thenReturn(null);
		service.searchFilmByLanguage("abc");

	}

	@Test
	public void findByLanguageIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(dao.searchFilmByLanguage("Sultan")).thenReturn(l);

		assertFalse(service.searchFilmByLanguage("Sultan").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByLanguageIfSystemError() {

		Mockito.when(dao.searchFilmByLanguage("abc")).thenThrow(new SQLException());
		service.searchFilmByLanguage("abc");

	}

	/*----------------- searchByActor() test cases -------------*/

	@Test(expected = java.lang.NullPointerException.class)
	public void findByActorInputNull() {
		service.searchFilmByActor(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByActorInputNotPresent() {

		Mockito.when(dao.searchFilmByActor(null)).thenReturn(null);
		service.searchFilmByActor(null);

	}

	@Test
	public void findByActorIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Actor a = new Actor();
		Mockito.when(dao.searchFilmByActor(a)).thenReturn(l);

		assertFalse(service.searchFilmByActor(a).isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByActorIfSystemerror() {
		Actor a = new Actor();
		Mockito.when(dao.searchFilmByActor(a)).thenThrow(new SQLException());
		service.searchFilmByActor(a);

	}

	/*----------------- searchByReleaseYear() test cases -------------*/

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void findByRealeaseYearInputNull() {
		service.searchFilmByRating((short) 0);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByRealeaseYearInputNotPresent() {

		Mockito.when(dao.searchFilmByRating((short) 2003)).thenReturn(null);
		service.searchFilmByRating((short) 2003);

	}

	@Test
	public void findByRealeaseYearIfInputPresent() {
		List<Film> l = new ArrayList<Film>();
		l.add(new Film());
		Mockito.when(dao.searchFilmByRealeaseYear((short) 2003)).thenReturn(l);

		assertFalse(service.searchFilmByRealeaseYear((short) 2003).isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByRealeaseYearIfSystemError() {

		Mockito.when(dao.searchFilmByRating((short) 2003)).thenThrow(new SQLException());
		service.searchFilmByRating((short) 2003);

	}

}
