/**
 * Created by jehaque on 13-Jun-16.
 */

app.controller('blogController', function ($scope, blogService) {
    $scope.searchText = " ";


    var callBack = function (data) {
        $scope.blogs = data;
    };

    blogService(callBack);


    $scope.upVoteCount = function (blog) {
        blog.likeCount++;

    }
});