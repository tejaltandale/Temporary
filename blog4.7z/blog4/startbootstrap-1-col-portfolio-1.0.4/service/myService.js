/**
 * Created by jehaque on 16-Jun-16.
 */
app.factory("blogService", function ($http) {
    return function (cb) {
        $http({
            method: 'GET',
            url: 'data/blog.json'
        }).then(function (response) {
            cb(response.data);
        }), function (response) {
            console.log("Something wrong");
        }
    }
});