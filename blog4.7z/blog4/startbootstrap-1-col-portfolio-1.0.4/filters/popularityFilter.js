/**
 * Created by jehaque on 15-Jun-16.
 */

app.filter("popularity", function (){
 
    var max = 0;
    return function(input, total) {
        total = parseInt(total);
        
        if (total > max) {
            max = total;
        }
        total=Math.round((5*total)/max);

        for (var i=0; i<total; i++) {
            input.push(i);
        }
        
        return input;
    };
   
});
