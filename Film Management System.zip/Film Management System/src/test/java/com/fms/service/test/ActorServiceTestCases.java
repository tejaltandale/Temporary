package com.fms.service.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fms.dao.IActorDao;
import com.fms.pojo.Actor;
import com.fms.pojo.Album;
import com.fms.pojo.Film;
import com.fms.service.ActorServiceImpl;

public class ActorServiceTestCases {

	private ActorServiceImpl service;

	@Mock
	private IActorDao dao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		service = new ActorServiceImpl(dao);
	}
	/* ---------------- addActor() test cases --------------------*/
	
	//if data is valid actor should be added
	@Test
	public void isValidDataActor() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName("Leonardo");
		actor.setLastName("DiCaprio");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(dao.save(actor)).thenReturn(true);

		assertEquals("success", service.addActor(actor));
	}

	//system error
	@Test(expected = java.lang.Exception.class)
	public void isSystemError() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName("Leonardo");
		actor.setLastName("DiCaprio");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(dao.save(actor)).thenThrow(new SQLException());

		service.addActor(actor);
	}
	
	//if data is invalid should show exception
	@Test(expected = java.lang.Exception.class)
	public void isInvalidDataActor() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName(null);
		actor.setLastName("DiCaprio");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(dao.save(actor)).thenReturn(false);

		service.addActor(actor);
	}

	//if input is null should throw error
	@Test(expected = java.lang.NullPointerException.class)
	public void isNullDataActor() {
		Actor actor = null;

		Mockito.when(dao.save(actor)).thenReturn(false);

		service.addActor(actor);
	}

	/*---------------modifyActor() test cases-----------*/
	//if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsActor() {
		Actor actor = null;
		service.modifyActor(actor);
	}

	//System error
	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInModifyActor() {
		Actor f = new Actor(2);
		Mockito.when(dao.modifyActor(f)).thenThrow(new SQLException());
		service.modifyActor(f);
	}
	
	//if actor is not present should show error
	@Test
	public void dataIsNotPresent() {
		Actor actor = new Actor(2);
		Mockito.when(dao.modifyActor(actor)).thenReturn(false);
		assertEquals("fail", service.modifyActor(actor));
	}

	//if data is present should modify
	@Test
	public void ifDataIsPresent() {
		Actor actor = new Actor(1);
		Mockito.when(dao.modifyActor(actor)).thenReturn(true);
		assertEquals("success", service.modifyActor(actor));

	}
	/*------------------deleteActor() test cases--------------*/
	


	//if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNullDelete() {
		Actor actor = null;
		Mockito.when(dao.deleteActor(actor)).thenReturn(false);
		service.deleteActor(actor);
	}
	
	//if data is not present
	@Test
	public void dataIsNotPresentDelete() {
		Actor f = new Actor(2);
		Mockito.when(dao.deleteActor(f)).thenReturn(false);
		assertEquals("fail", service.modifyActor(f));
	}
	
	//if data is present delete
	@Test
	public void ifDataIsPresentDelele() {
		Actor actor = new Actor(1);
		Mockito.when(dao.deleteActor(actor)).thenReturn(true);
		assertEquals("success", service.deleteActor(actor));

	}
	
	//system error 
	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInDeleteActor() {
		Actor actor = new Actor(2);
		Mockito.when(dao.deleteActor(actor)).thenThrow(new SQLException());
		service.deleteActor(actor);
	}

	/*------------------searchByGender() test cases--------------*/
	
	//if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void searchByGenderInputNull() {
		service.searchByGender(null);
	}

	//if input is not present
	@Test(expected = java.lang.NullPointerException.class)
	public void findByGenderInputNotPresent() {

		Mockito.when(dao.searchByGender("abc")).thenReturn(null);
		service.searchByGender("abc");

	}

	//if data is present should display
	@Test
	public void findByTitleIfInputPresent() {
		List<Actor> actor = new ArrayList<Actor>();
		actor.add(new Actor());
		Mockito.when(dao.searchByGender("male")).thenReturn(actor);
		

	}
	
	//system error
	@Test(expected = java.lang.Exception.class)
	public void searchByGenderIfSystemError() {
		List<Actor> actor = new ArrayList<Actor>();
		actor.add(new Actor());
		Mockito.when(dao.searchByGender("male")).thenThrow(new SQLException());
		service.searchByGender("male");

	}
	
	/*------------------searchByName() test cases--------------*/

	//if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void searchByNameInputNull() {
		service.searchByName(null, "");
	}

	//if input is null
	@Test(expected = java.lang.NullPointerException.class)
	public void findByNameInputNotPresent() {

		Mockito.when(dao.searchByName("abc", "xyz")).thenReturn(null);
		service.searchByName("abc", "xyz");

	}

	//if input is present
	@Test
	public void findByNameIfInputPresent() {
		List<Actor> actor = new ArrayList<Actor>();
		actor.add(new Actor());
		Mockito.when(dao.searchByName("Leonardo", "DiCaprio")).thenReturn(actor);

	}

	//system error
	@Test(expected = java.lang.Exception.class)
	public void searchByNameIfSystemError() {
		List<Actor> actor = new ArrayList<Actor>();
		actor.add(new Actor());
		Mockito.when(dao.searchByName("Leonardo", "DiCaprio")).thenThrow(new SQLException());
		service.searchByName("Leonardo", "DiCaprio");

	}

}
