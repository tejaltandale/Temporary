package com.fms.service;

import java.util.List;

import com.fms.pojo.Actor;

public interface IActorService {
	String addActor(Actor actor);

	List<Actor> searchByName(String firstName, String lastName);

	List<Actor> searchByGender(String Gender);

	String deleteActor(Actor actor);

	String modifyActor(Actor actor);

}
