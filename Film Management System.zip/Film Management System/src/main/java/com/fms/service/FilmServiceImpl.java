package com.fms.service;

import java.util.List;

import com.fms.dao.IFilmDao;
import com.fms.pojo.Actor;
import com.fms.pojo.Film;

public class FilmServiceImpl implements IFilmService {

	private IFilmDao dao;

	public FilmServiceImpl() {
		super();
	}

	public FilmServiceImpl(IFilmDao dao) {
		super();
		this.dao = dao;
	}

	public String addFilm(Film film) {
		Film f = film;
		if (f == null) {
			throw new NullPointerException();
		} else {

			if (f.getTitle() == null)
				throw new IllegalArgumentException();
			if (f.getDescription() == null)
				throw new IllegalArgumentException();
			if (f.getReleaseYear() == 0)
				throw new IllegalArgumentException();
			if (f.getAlbum() == null)
				throw new IllegalArgumentException();
			if (f.getLanguage() == null)
				throw new IllegalArgumentException();
			if (f.getActor() == null)
				throw new IllegalArgumentException();
			if (f.getCategory() == null)
				throw new IllegalArgumentException();
			if (f.getRating() < 1 || f.getRating() > 6)
				throw new IllegalArgumentException();
			if (f.getDeleteDate() == null)
				throw new IllegalArgumentException();
			if (f.getLength() < 0)
				throw new IllegalArgumentException();
			if (f.getCreateDate() == null)
				throw new IllegalArgumentException();
			try {
				dao.save(f);
				return "success";
			} catch (Exception e) {
				return "fail";
			}
		}

	}

	public String modifyFilm(Film film) {
		if (film == null) {
			throw new NullPointerException();
		}
		try {

			if (dao.modifyFilm(film)) {
				return "success";
			}
		} catch (Exception e) {

			return "fail";
		}
		return "fail";
	}

	public String deleteFilm(Film film) {
		if (film == null) {
			throw new NullPointerException();
		}
		try {
			if (dao.deleteFilm(film)) {

				return "success";
			}
			return "fail";
		} catch (Exception e) {

			return "System Error";
		}

	}

	public List<Film> searchFilmByTitle(String title) {
		List<Film> film = null;
		if (title == null) {
			throw new NullPointerException();
		}
		try {
			film = dao.searchFilmByTitle(title);

		} catch (Exception e) {
			return null;
		}

		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByCategory(String category) {
		List<Film> film = null;
		if (category == null) {
			throw new NullPointerException();
		}
		try {
			film = dao.searchFilmByCategory(category);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByRating(short rating) {
		List<Film> film = null;
		if (rating == 0) {
			throw new IllegalArgumentException();
		}
		try {
			film = dao.searchFilmByRating(rating);
		} catch (Exception e) {

		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByLanguage(String lang) {
		List<Film> film = null;
		if (lang == null) {
			throw new NullPointerException();
		}
		try {
			film = dao.searchFilmByLanguage(lang);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByActor(Actor actor) {
		List<Film> film = null;
		if (actor == null) {
			throw new NullPointerException();
		}
		try {
			film = dao.searchFilmByActor(actor);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByReleaseYear(short year) {
		List<Film> film = null;
		if (year == 0) {
			throw new IllegalArgumentException();
		}
		try {
			film = dao.searchFilmByReleaseYear((short) year);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

}
