
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
public class PojoTest {
	Pojo p;
	@Before
	public void init() {
		 p=new Pojo();
		
	}

	//1. Factorial of 0 is 1.
	//2. Factorial of 1 is 1.
	//3. Factorial of 5 is 120.
	//4. Factorial of Negative Numbers cannot be calculated.
	
	@Test
	public void FactorialOfZeroIsOne() {
		assertEquals(1,p.isFactorial(0));
	}
	
	@Test
	public void FactorialOfOneIsOne() {
		assertEquals(1,p.isFactorial(1));
	}
	@Test
	public void FactorialOfFiveIsOneTwenty() {
		assertEquals(120,p.isFactorial(5));
	}
	@Test(expected=IllegalArgumentException.class)
	public void FactorialOfNegativeNumbersCannotBeCalculated() {
		p.isFactorial(-3);
		
	}
	
	@Test
	public void OneFifytyThreeIsArmstrong() {
		//assertEquals(153,p.isFactorial(153));
		assertEquals(true, p.isArmstrong(153));
	}
	@Test 
	public void twentyIsNotArmStrong(){
		assertNotEquals(true, p.isArmstrong(20));
		
	}

}
