package com.fms.pojo;

import java.util.Date;

public class Category {
	int id;
	String name;
	Date createDate;
	Date deleteDate;
	
	//constructors
	
	public Category() {
		super();
	}
	
	
	public Category(int id) {
		super();
		this.id = id;
	}


	//Setters and getters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	
	//ToString
	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + ", createDate=" + createDate + ", deleteDate=" + deleteDate
				+ "]";
	}
}
