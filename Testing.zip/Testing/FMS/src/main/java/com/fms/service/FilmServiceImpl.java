package com.fms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mockito.Mockito;

import com.fms.dao.IFilmDao;
import com.fms.pojo.Film;

public class FilmServiceImpl implements IFilmService {

	private IFilmDao dao;

	public FilmServiceImpl(IFilmDao dao) {
		super();
		this.dao = dao;
	}

	public String addFilm(Film f) {
		if (f == null) {
			throw new NullPointerException();
		}

		if (f.getTitle() == null)
			throw new IllegalArgumentException();
		if (f.getDescription() == null)
			throw new IllegalArgumentException();
		if (f.getReleaseYear() == null)
			throw new IllegalArgumentException();
		if (f.getLanguage() == null)
			throw new IllegalArgumentException();
		if (f.getActor() == null)
			throw new IllegalArgumentException();
		if (f.getCategory() == null)
			throw new IllegalArgumentException();
		if (f.getRating() == 0 || f.getRating() > 5)
			throw new IllegalArgumentException();
		if (f.getCreateDate() == null)
			throw new IllegalArgumentException();
		if (f.getLength() == 0)
			throw new IllegalArgumentException();
		if (f.getAlbum() == null)
			throw new IllegalArgumentException();

		if (dao.addFilm(f)) {
			return "success";
		}

		return "fail";
	}

	public List<Film> searchByTitle(String title) {
		if (title == null) {
			throw new NullPointerException();
		}
		if (title == "") {
			throw new IllegalArgumentException();
		}
		if (dao.searchByTitle(title) != null) {
			return new ArrayList<Film>();

		} else if (dao.searchByTitle(title) == null) {

		}
		return null;

	}

	public String modifyFilm(String title) {
		if (title == null) {
			throw new NullPointerException();
		}

		return "fail";
	}

	public String deleteFilm(String title) {

		return null;
	}

	public List<Film> searchByLanguage(String language) {
		if (language == null) {
			throw new NullPointerException();
		}
		if (language == "") {
			throw new IllegalArgumentException();
		}
		if (dao.searchByLanguage(language) != null) {
			return new ArrayList<Film>();

		} else if (dao.searchByLanguage(language) == null) {

		}
		return null;
	}

	public List<Film> searchByReleaseYear(Date year) {
		if (year == null) {
			throw new NullPointerException();
		}
		if (year == Date.parse("") {
			throw new IllegalArgumentException();
		}
		if (dao.searchByReleaseYear(year) != null) {
			return new ArrayList<Film>();

		} else if (dao.searchByReleaseYear(year) == null) {

		}
		return null;
	}

	public List<Film> searchByCategory(String category) {
		if (category == null) {
			throw new NullPointerException();
		}
		if (category == "") {
			throw new IllegalArgumentException();
		}
		if (dao.searchByCategory(category) != null) {
			return new ArrayList<Film>();

		} else if (dao.searchByCategory(category) == null) {

		}
		return null;
	}

	public List<Film> searchByActor(String actor) {
		if (actor == null) {
			throw new NullPointerException();
		}
		if (actor == "") {
			throw new IllegalArgumentException();
		}
		if (dao.searchByActor(actor) != null) {
			return new ArrayList<Film>();

		} else if (dao.searchByActor(actor) == null) {

		}
		return null;
	}

	public List<Film> searchByRating(byte rating) {
		if (rating == null) {
			throw new NullPointerException();
		}
		if (rating== "") {
			throw new IllegalArgumentException();
		}
		if (dao.searchByRating(rating) != null) {
			return new ArrayList<Film>();

		} else if (dao.searchByRating(rating) == null) {

		}
		return null;
	}

}
