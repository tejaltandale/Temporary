package com.fms.dao;

import com.fms.pojo.Actor;

public interface IActorDao {
	public boolean addActor(Actor actor);
}
