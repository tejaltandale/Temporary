package com.fms.exception;

public class SystemError extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
