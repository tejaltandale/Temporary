package com.fms.service;

import java.util.List;

import com.fms.pojo.Actor;

public interface IActorService {
	public String addActor(Actor actor);
	public List<Actor> searchActorByName(String firstName,String lastName);
	public String removeActor(String firstName,String lastName);
	public String modifyActor(String firstName,String lastName);
	
}
