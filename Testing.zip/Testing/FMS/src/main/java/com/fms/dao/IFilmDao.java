package com.fms.dao;

import java.util.Date;
import java.util.List;

import com.fms.pojo.Film;

public interface IFilmDao {
	public boolean addFilm (Film film);
	
	public List<Film> searchByTitle(String title);
	
	public List<Film> searchByLanguage(String language);
	
	public List<Film> searchByReleaseYear(Date year);
	
	public List<Film> searchByCategory(String category);
	
	public List<Film> searchByActor(String actor);
	
	public List<Film> searchByRating(byte rating);
	
	public boolean modifyFilm(String title);
	
	public String deleteFilm(String title);	
}
