package com.fms.service;

import java.util.Date;
import java.util.List;

import com.fms.pojo.Film;

public interface IFilmService {

	public String addFilm(Film f);

	public List<Film> searchByTitle(String title);

	public List<Film> searchByLanguage(String language);

	public List<Film> searchByReleaseYear(Date year);

	public List<Film> searchByCategory(String category);

	public List<Film> searchByActor(String actor);

	public List<Film> searchByRating(byte rating);

	public String modifyFilm(String title);

	public String deleteFilm(String title);

}
