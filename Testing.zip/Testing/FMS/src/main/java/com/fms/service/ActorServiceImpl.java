package com.fms.service;

import java.util.List;

import com.fms.dao.IActorDao;
import com.fms.pojo.Actor;

public class ActorServiceImpl implements IActorService {

	private IActorDao dao;

	public ActorServiceImpl(IActorDao dao) {
		super();
		this.dao= dao;
	}

	public String addActor(Actor actor) {

		if (actor == null) {
			throw new NullPointerException();
		}
		
		
		if (actor.getFirstName()==null) throw new IllegalArgumentException();
		if (actor.getLastName()==null) throw new IllegalArgumentException();
		if (actor.getGender()==null) throw new IllegalArgumentException();
		if (actor.getAlbum()==null) throw new IllegalArgumentException();
		
		
		
		if (dao.addActor(actor)) {
			return "success";
		}
	
		return "fail";

	}

	public List<Actor> searchActorByName(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeActor(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

	public String modifyActor(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

}
