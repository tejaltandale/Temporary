package com.FilmManagementSystem.FMS;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import org.junit.Test;

import com.fms.dao.IFilmDao;
import com.fms.pojo.Actor;
import com.fms.pojo.Album;
import com.fms.pojo.Category;
import com.fms.pojo.Film;
import com.fms.service.FilmServiceImpl;
import com.fms.service.IFilmService;

public class FilmServiceTest {
	private IFilmService service;
	@Mock
	private IFilmDao dao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		service = new FilmServiceImpl(dao);
	}

	/*--------------- addFilm method test cases ---------------------- */

	// if details are valid values should be added
	@SuppressWarnings("deprecation")
	@Test
	public void ifDetailsAreValidFilmShouldBeAdded() {
		Film f = new Film();

		List<Actor> actor = new ArrayList<Actor>();
		List<Category> category = new ArrayList<Category>();
		Date d1 = new Date();
		d1.setYear(2012);

		f.setTitle("Avatar");
		f.setDescription("Sci-Fi");
		f.setReleaseYear(d1);
		f.setLanguage("English");
		f.setActor(actor);
		f.setCategory(category);
		f.setRating((byte) 5);
		f.setCreateDate(d1);
		f.setLength((short) 180);
		f.setAlbum(new Album());

		Mockito.when(dao.addFilm(f)).thenReturn(true);
		assertEquals("success", service.addFilm(f));
	}

	// if input is null
	@Test(expected = NullPointerException.class)
	public void ifInputIsNull() {
		Film f = null;

		Mockito.when(dao.addFilm(f)).thenReturn(false);
		assertEquals("fail", service.addFilm(f));

	}

	// if details are not valid should not be added

	@Test(expected = IllegalArgumentException.class)
	public void ifDetailsAreNotValidFilmShouldNotBeAdded() {
		Film f = new Film();

		List<Actor> actor = new ArrayList<Actor>();
		List<Category> category = new ArrayList<Category>();

		f.setTitle(null);
		f.setDescription("Sci-Fi");
		f.setReleaseYear(null);
		f.setLanguage("English");
		f.setActor(actor);
		f.setCategory(category);
		f.setRating((byte) 5);
		f.setCreateDate(null);
		f.setLength((short) 180);
		f.setAlbum(new Album());

		Mockito.when(dao.addFilm(f)).thenReturn(false);
		assertEquals("fail", service.addFilm(f));
	}

	/* ----------------search by title method test cases --------------------------*/

	// if input is null
	@Test(expected = NullPointerException.class)
	public void ifInputisNullSearchByTitle() {
		String f = null;
		Mockito.when(dao.searchByTitle(f)).thenReturn(null);
		assertEquals(null, service.searchByTitle(f));

	}

	// if input is not present show error

	@Test(expected = IllegalArgumentException.class)
	public void ifInputisNotPresentSearchByTitle() {
		String f = "";
		Mockito.when(dao.searchByTitle(f)).thenReturn(null);
		assertEquals(null, service.searchByTitle(f));

	}

	// if input is present it should return details
	
	@Test
	public void ifTitleIsPresentItShouldRetrieveDetails() {
		String f = "avatar";
		List<Film> details = new ArrayList<Film>();
		Mockito.when(dao.searchByTitle(f)).thenReturn(details);
		assertEquals(details, service.searchByTitle(f));
		
	}
	
	// if input is present and it is not returning any details
	
		@Test
		public void ifTitleIsPresentAndNotAbleToRetrieveDetailsThrowError() {
			String f = "avatar";
			List<Film> details = new ArrayList<Film>();
			Mockito.when(dao.searchByTitle(f)).thenReturn(null);
			assertEquals(null, service.searchByTitle(f));
			
		}
	
	
		
		/* ----------------search by language method test cases --------------------------*/

		// if input is null
//		@Test(expected = NullPointerException.class)
//		public void ifInputisNullSearchByLanguage() {
//			String lang = null;
//			Mockito.when(dao.searchByLanguage((lang)).thenReturn(null);
//			assertEquals(null, service.searchByLanguage(lang));
//
//		}

		// if input is not present show error

		@Test(expected = IllegalArgumentException.class)
		public void ifInputisNotPresentSearchByLanguage() {
			String f = "";
			Mockito.when(dao.searchByLanguage(f)).thenReturn(null);
			assertEquals(null, service.searchByLanguage(f));

		}

		// if input is present it should return details
		
		@Test
		public void ifLanguageIsPresentItShouldRetrieveDetails() {
			String f = "english";
			List<Film> details = new ArrayList<Film>();
			Mockito.when(dao.searchByLanguage(f)).thenReturn(details);
			assertEquals(details, service.searchByLanguage(f));
			
		}
		
		// if input is present and it is not returning any details
		
			@Test
			public void ifLanguageIsPresentAndNotAbleToRetrieveDetailsThrowError() {
				String f = "english";
				Mockito.when(dao.searchByLanguage(f)).thenReturn(null);
				assertEquals(null, service.searchByLanguage(f));
				
			}
		
	

	/*------------------ Modify method test cases------------------------------*/

	// if input is null
	@Test(expected = NullPointerException.class)
	public void ifInModifyInputIsNull() {
		String title = null;
		Mockito.when(dao.modifyFilm(title)).thenReturn(false);
		assertEquals("fail", service.modifyFilm(title));

	}

}
