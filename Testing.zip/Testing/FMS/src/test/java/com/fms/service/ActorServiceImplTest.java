package com.fms.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fms.dao.IActorDao;
import com.fms.dao.IFilmDao;
import com.fms.pojo.Actor;
import com.fms.pojo.Album;
import com.fms.pojo.Category;
import com.fms.pojo.Film;

public class ActorServiceImplTest {

	private IActorService service;
	@Mock private IActorDao dao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		service = new ActorServiceImpl(dao);
	}
	
	// addfilm() test cases
	
	//if details are valid values should be added
	@SuppressWarnings("deprecation")
	@Test
	public void ifDetailsAreValidActorShouldBeAdded() {
		Actor actor = new Actor();
		
		actor.setFirstName("Leonardo");
		actor.setLastName("DiCaprio");
		actor.setGender("male");
		actor.setAlbum(new Album());
					
		Mockito.when(dao.addActor(actor)).thenReturn(true);
		assertEquals("success", service.addActor(actor));
	}
	
	//if input is null
	@Test(expected=NullPointerException.class)
	public void ifInputIsNull() {
		Actor actor = null;
		
		Mockito.when(dao.addActor(actor)).thenReturn(false);
		assertEquals("fail",service.addActor(actor));
		
	}
	
	//if details are not valid should not be added
	
	@Test(expected = IllegalArgumentException.class)
	public void ifDetailsAreNotValidFilmShouldNotBeAdded() {
Actor actor = new Actor();
		
		actor.setFirstName("Leonardo");
		actor.setLastName(null);
		actor.setGender("male");
		actor.setAlbum(new Album());
					
		Mockito.when(dao.addActor(actor)).thenReturn(false);
		assertEquals("fail", service.addActor(actor));
	}

	

}
